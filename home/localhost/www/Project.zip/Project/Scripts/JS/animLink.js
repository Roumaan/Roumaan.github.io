function goToAnim (fp, ID) {
	document.location.href = fp + ID;
}